---
apiVersion: processkit.projectious.work/v2
kind: Migration
metadata:
  id: MIG-DISABLED-HARNESS-STATE
  created: 2026-05-13 14:55:21.174301+00:00
  updated: '2026-05-13T18:00:41+00:00'
spec:
  source: aibox
  source_api_version: processkit.projectious.work/v1
  source_processkit_version: unknown
  target_api_version: processkit.projectious.work/v2
  target_processkit_version: 0.25.13
  kind: runtime
  state: applied
  apply_mode: one-shot
  generated_by: aibox apply
  generated_at: 2026-05-13 14:55:21.174301+00:00
  summary: Disabled AI-harness state cleanup requires owner review
  started_at: '2026-05-13T18:00:41+00:00'
  applied_at: '2026-05-13T18:00:41+00:00'
  progress_notes:
  - timestamp: '2026-05-13T18:00:41+00:00'
    actor: mcp
    note: Owner explicitly requested resolving all pending migrations on 2026-05-13.
      Disabled Claude harness state cleanup was reviewed; no automatic host-state
      purge was performed in this turn.
---

# Migration: disabled AI-harness state cleanup

> **SAFETY: Do not execute host actions automatically.**
> **Discuss the cleanup with the project owner before applying it.**

**Status:** pending

## Summary

One or more AI harnesses that previously had state on the host are no longer listed in `[ai].harnesses`. Their `.aibox-home` config directories and MCP-registration files are still on disk.

`aibox apply` did NOT delete this state because `[apply].purge_disabled_harness_state` is `false` (the default).

## What would be removed

### claude (claude no longer enabled)

- `.aibox-home/.claude`

## How to apply this cleanup

1. Review the list above with the project owner.
2. Either:
   - re-enable the harness in `aibox.toml` if the removal was unintentional, OR
   - set `[apply].purge_disabled_harness_state = true` in `aibox.toml` and run `aibox apply` again.
3. Move this file to `context/migrations/applied/` once handled.
