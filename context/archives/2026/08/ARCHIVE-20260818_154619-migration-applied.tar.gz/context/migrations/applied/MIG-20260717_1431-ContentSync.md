---
apiVersion: processkit.projectious.work/v1
kind: Migration
metadata:
  id: MIG-20260717_1431-ContentSync
  created: 2026-07-17 14:31:44+00:00
  updated: '2026-07-17T14:32:45+00:00'
spec:
  source: processkit
  source_url: https://github.com/projectious-work/processkit.git
  from_version: v0.27.1
  to_version: v0.27.2
  state: applied
  generated_by: aibox apply
  generated_at: 2026-07-17 14:31:44+00:00
  summary: 0 changed upstream, 0 conflicts, 1 new, 289 removed, 0 stale-removed (28
    groups affected)
  affected_groups:
  - AGENTS
  - context
  - context/artifacts
  - context/roles
  - lib
  - schemas/INDEX
  - schemas/actor
  - schemas/artifact
  - schemas/binding
  - schemas/category
  - schemas/constraint
  - schemas/context
  - schemas/decisionrecord
  - schemas/discussion
  - schemas/gate
  - schemas/logentry
  - schemas/migration
  - schemas/note
  - schemas/role
  - schemas/roleslot
  - schemas/scope
  - schemas/team-member
  - schemas/workitem
  - skills/INDEX.md
  - skills/data-ai
  - skills/design
  - skills/devops
  - skills/processkit
  affected_files:
  - path: AGENTS.md
    classification: changed-locally-only
  - path: context/.processkit-mcp-manifest.json
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen2-5-72b.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen2-5-coder-32b.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-235b.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-6-max-preview.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-6-plus.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-coder.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-haiku.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-opus.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-sonnet.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-aws-amazon-nova-2-lite.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-cohere-command-a.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-cohere-command-r-plus.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-r.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v4-flash.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v4-pro.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-2-5-flash.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-2-5-pro.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-1-pro.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-flash-preview.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-flash.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-pro-preview.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-flash.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-google-gemma-3-27b.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-3-70b.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-4-maverick.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-4-scout.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-microsoft-phi.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-minimax-minimax-m.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-minimax-minimax-text.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-mistral-codestral.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-mistral-devstral.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-deep-think.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-large.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-medium.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-small.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-moonshot-kimi-k2-6.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-nvidia-nvidia-nemotron-3-super-120b.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-4o.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-2-codex.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-2-pro.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-5-pro.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-pro.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-o3.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-openai-o4-mini.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-3-5.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-3.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-1-fast.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-1.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-heavy.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-xai-grok.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1424-ModelSpec-zai-glm.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-code-balanced.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-code-deep.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-code-fast.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-general-balanced.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-general-deep.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-general-fast.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-governed-deep.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-research-deep.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260503_1832-ModelProfile-writing-balanced.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260504_1425-ModelSpec-openai-gpt-5-3-codex-spark.md
    classification: removed-upstream
  - path: context/artifacts/ART-20260505_1545-ModelSpec-xiaomi-mimo-7b.md
    classification: removed-upstream
  - path: context/roles/ROLE-account-executive.md
    classification: removed-upstream
  - path: context/roles/ROLE-ai-research-scientist.md
    classification: removed-upstream
  - path: context/roles/ROLE-assistant.md
    classification: removed-upstream
  - path: context/roles/ROLE-brand-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-business-operations-analyst.md
    classification: removed-upstream
  - path: context/roles/ROLE-ceo.md
    classification: removed-upstream
  - path: context/roles/ROLE-cfo.md
    classification: removed-upstream
  - path: context/roles/ROLE-chief-of-staff.md
    classification: removed-upstream
  - path: context/roles/ROLE-cloud-architect.md
    classification: removed-upstream
  - path: context/roles/ROLE-cloud-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-cmo.md
    classification: removed-upstream
  - path: context/roles/ROLE-community-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-compliance-officer.md
    classification: removed-upstream
  - path: context/roles/ROLE-content-marketer.md
    classification: removed-upstream
  - path: context/roles/ROLE-controller.md
    classification: removed-upstream
  - path: context/roles/ROLE-coo.md
    classification: removed-upstream
  - path: context/roles/ROLE-cpo.md
    classification: removed-upstream
  - path: context/roles/ROLE-cto.md
    classification: removed-upstream
  - path: context/roles/ROLE-customer-success-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-data-architect.md
    classification: removed-upstream
  - path: context/roles/ROLE-data-protection-officer.md
    classification: removed-upstream
  - path: context/roles/ROLE-data-scientist.md
    classification: removed-upstream
  - path: context/roles/ROLE-database-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-devops-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-embedded-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-enterprise-architect.md
    classification: removed-upstream
  - path: context/roles/ROLE-financial-analyst.md
    classification: removed-upstream
  - path: context/roles/ROLE-general-counsel.md
    classification: removed-upstream
  - path: context/roles/ROLE-learning-development-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-machine-learning-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-observability-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-pr-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-product-designer.md
    classification: removed-upstream
  - path: context/roles/ROLE-product-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-product-marketing-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-product-owner.md
    classification: removed-upstream
  - path: context/roles/ROLE-program-manager.md
    classification: removed-upstream
  - path: context/roles/ROLE-qa-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-recruiter.md
    classification: removed-upstream
  - path: context/roles/ROLE-research-scientist.md
    classification: removed-upstream
  - path: context/roles/ROLE-sales-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-scrum-master.md
    classification: removed-upstream
  - path: context/roles/ROLE-security-architect.md
    classification: removed-upstream
  - path: context/roles/ROLE-security-operations-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-seo-specialist.md
    classification: removed-upstream
  - path: context/roles/ROLE-site-reliability-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-software-engineer.md
    classification: removed-upstream
  - path: context/roles/ROLE-solutions-architect.md
    classification: removed-upstream
  - path: context/roles/ROLE-technical-writer.md
    classification: removed-upstream
  - path: context/roles/ROLE-treasury-analyst.md
    classification: removed-upstream
  - path: context/roles/ROLE-ux-designer.md
    classification: removed-upstream
  - path: context/schemas/INDEX.md
    classification: removed-upstream
  - path: context/schemas/actor.yaml
    classification: removed-upstream
  - path: context/schemas/artifact.yaml
    classification: removed-upstream
  - path: context/schemas/binding.yaml
    classification: removed-upstream
  - path: context/schemas/category.yaml
    classification: removed-upstream
  - path: context/schemas/constraint.yaml
    classification: removed-upstream
  - path: context/schemas/context.yaml
    classification: removed-upstream
  - path: context/schemas/decisionrecord.yaml
    classification: removed-upstream
  - path: context/schemas/discussion.yaml
    classification: removed-upstream
  - path: context/schemas/gate.yaml
    classification: removed-upstream
  - path: context/schemas/logentry.yaml
    classification: removed-upstream
  - path: context/schemas/migration.yaml
    classification: removed-upstream
  - path: context/schemas/note.yaml
    classification: removed-upstream
  - path: context/schemas/role.yaml
    classification: removed-upstream
  - path: context/schemas/roleslot.yaml
    classification: removed-upstream
  - path: context/schemas/scope.yaml
    classification: removed-upstream
  - path: context/schemas/team-member.yaml
    classification: removed-upstream
  - path: context/schemas/workitem.yaml
    classification: removed-upstream
  - path: context/skills/INDEX.md
    classification: removed-upstream
  - path: context/skills/_lib/README.md
    classification: removed-upstream
  - path: context/skills/_lib/processkit/__init__.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/config.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/entity.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/frontmatter.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/__init__.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/catalog.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/lazy.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/loader.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/naming.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/permissions.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/proxy.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/registry.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/runtime.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/session.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/gateway/transports.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/ids.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/index.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/log.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/paths.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/schema.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/state_machine.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/test_frontmatter.py
    classification: removed-upstream
  - path: context/skills/_lib/processkit/test_ids.py
    classification: removed-upstream
  - path: context/skills/data-ai/ai-fundamentals/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/ai-fundamentals/references/math-foundations.md
    classification: removed-upstream
  - path: context/skills/data-ai/ai-fundamentals/references/ml-concepts.md
    classification: removed-upstream
  - path: context/skills/data-ai/data-pipeline/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/data-quality/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/data-science/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/data-science/references/statistical-methods.md
    classification: removed-upstream
  - path: context/skills/data-ai/data-science/references/tidy-data-principles.md
    classification: removed-upstream
  - path: context/skills/data-ai/data-science/references/visualization-guidelines.md
    classification: removed-upstream
  - path: context/skills/data-ai/embedding-vectordb/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/feature-engineering/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/llm-evaluation/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/ml-pipeline/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/ml-pipeline/references/pipeline-stages.md
    classification: removed-upstream
  - path: context/skills/data-ai/pandas-polars/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/pandas-polars/references/api-comparison.md
    classification: removed-upstream
  - path: context/skills/data-ai/prompt-engineering/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/prompt-engineering/references/techniques-catalog.md
    classification: removed-upstream
  - path: context/skills/data-ai/rag-engineering/SKILL.md
    classification: removed-upstream
  - path: context/skills/data-ai/rag-engineering/references/chunking-strategies.md
    classification: removed-upstream
  - path: context/skills/data-ai/rag-engineering/references/evaluation.md
    classification: removed-upstream
  - path: context/skills/data-ai/rag-engineering/references/retrieval-patterns.md
    classification: removed-upstream
  - path: context/skills/design/excalidraw/SKILL.md
    classification: removed-upstream
  - path: context/skills/design/excalidraw/references/json-schema.md
    classification: removed-upstream
  - path: context/skills/design/frontend-design/SKILL.md
    classification: removed-upstream
  - path: context/skills/design/frontend-design/references/accessibility-checklist.md
    classification: removed-upstream
  - path: context/skills/design/logo-design/SKILL.md
    classification: removed-upstream
  - path: context/skills/design/logo-design/references/design-principles.md
    classification: removed-upstream
  - path: context/skills/design/mobile-app-design/SKILL.md
    classification: removed-upstream
  - path: context/skills/design/mobile-app-design/references/platform-guidelines.md
    classification: removed-upstream
  - path: context/skills/design/seo-optimization/SKILL.md
    classification: removed-upstream
  - path: context/skills/design/seo-optimization/references/technical-seo-checklist.md
    classification: removed-upstream
  - path: context/skills/devops/alerting-oncall/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/ci-cd-setup/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/container-orchestration/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/container-orchestration/references/compose-patterns.md
    classification: removed-upstream
  - path: context/skills/devops/distributed-tracing/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/dns-networking/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/dns-networking/references/protocol-reference.md
    classification: removed-upstream
  - path: context/skills/devops/dns-networking/references/troubleshooting-tools.md
    classification: removed-upstream
  - path: context/skills/devops/dockerfile-review/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/incident-response/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/kubernetes-basics/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/kubernetes-basics/references/cluster-architecture.md
    classification: removed-upstream
  - path: context/skills/devops/kubernetes-basics/references/resource-cheatsheet.md
    classification: removed-upstream
  - path: context/skills/devops/kubernetes-basics/references/troubleshooting.md
    classification: removed-upstream
  - path: context/skills/devops/linux-administration/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/linux-administration/references/commands-cheatsheet.md
    classification: removed-upstream
  - path: context/skills/devops/linux-administration/references/systemd-reference.md
    classification: removed-upstream
  - path: context/skills/devops/logging-strategy/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/logging-strategy/references/structured-logging.md
    classification: removed-upstream
  - path: context/skills/devops/metrics-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/metrics-management/assets/metric-spec.yaml
    classification: removed-upstream
  - path: context/skills/devops/metrics-monitoring/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/metrics-monitoring/references/metric-types.md
    classification: removed-upstream
  - path: context/skills/devops/postmortem-writing/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/release-semver/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/release-semver/commands/pk-publish.md
    classification: removed-upstream
  - path: context/skills/devops/release-semver/commands/pk-release.md
    classification: removed-upstream
  - path: context/skills/devops/repo-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/devops/repo-management/commands/pk-repo-reconcile.md
    classification: removed-upstream
  - path: context/skills/devops/repo-management/mcp/SERVER.md
    classification: removed-upstream
  - path: context/skills/devops/repo-management/mcp/mcp-config.json
    classification: removed-upstream
  - path: context/skills/devops/repo-management/mcp/server.py
    classification: removed-upstream
  - path: context/skills/devops/repo-management/scripts/test_repo_management.py
    classification: removed-upstream
  - path: context/skills/devops/terraform-basics/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/agent-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/agent-management/references/coordination-patterns.md
    classification: removed-upstream
  - path: context/skills/processkit/aggregate-mcp/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/aggregate-mcp/mcp/mcp-config.aggregate.json
    classification: removed-upstream
  - path: context/skills/processkit/aggregate-mcp/mcp/server.py
    classification: removed-upstream
  - path: context/skills/processkit/aggregate-mcp/scripts/test_aggregate_mcp.py
    classification: removed-upstream
  - path: context/skills/processkit/artifact-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/artifact-management/mcp/SERVER.md
    classification: removed-upstream
  - path: context/skills/processkit/artifact-management/mcp/mcp-config.json
    classification: removed-upstream
  - path: context/skills/processkit/artifact-management/mcp/server.py
    classification: removed-upstream
  - path: context/skills/processkit/binding-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/binding-management/assets/binding.yaml
    classification: removed-upstream
  - path: context/skills/processkit/binding-management/mcp/SERVER.md
    classification: removed-upstream
  - path: context/skills/processkit/binding-management/mcp/mcp-config.json
    classification: removed-upstream
  - path: context/skills/processkit/binding-management/mcp/server.py
    classification: removed-upstream
  - path: context/skills/processkit/binding-management/scripts/test_binding_management.py
    classification: removed-upstream
  - path: context/skills/processkit/eval-gate-authoring/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/eval-gate-authoring/mcp/SERVER.md
    classification: removed-upstream
  - path: context/skills/processkit/eval-gate-authoring/mcp/mcp-config.json
    classification: removed-upstream
  - path: context/skills/processkit/eval-gate-authoring/mcp/server.py
    classification: removed-upstream
  - path: context/skills/processkit/eval-gate-authoring/scripts/test_eval_gate_authoring.py
    classification: removed-upstream
  - path: context/skills/processkit/event-log/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/event-log/assets/logentry.yaml
    classification: removed-upstream
  - path: context/skills/processkit/event-log/examples/workitem-transitioned.md
    classification: removed-upstream
  - path: context/skills/processkit/event-log/mcp/SERVER.md
    classification: removed-upstream
  - path: context/skills/processkit/event-log/mcp/mcp-config.json
    classification: removed-upstream
  - path: context/skills/processkit/event-log/mcp/server.py
    classification: removed-upstream
  - path: context/skills/processkit/event-log/scripts/test_log_event.py
    classification: removed-upstream
  - path: context/skills/processkit/index-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/index-management/config/settings.toml
    classification: removed-upstream
  - path: context/skills/processkit/index-management/mcp/SERVER.md
    classification: removed-upstream
  - path: context/skills/processkit/index-management/mcp/mcp-config.json
    classification: removed-upstream
  - path: context/skills/processkit/index-management/mcp/server.py
    classification: removed-upstream
  - path: context/skills/processkit/index-management/scripts/test_db_result_limits.py
    classification: removed-upstream
  - path: context/skills/processkit/index-management/scripts/test_get_entity_by_path_and_list_entities.py
    classification: removed-upstream
  - path: context/skills/processkit/index-management/scripts/test_index_management_v1_penalty.py
    classification: removed-upstream
  - path: context/skills/processkit/note-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/note-management/commands/pk-note-promote.md
    classification: removed-upstream
  - path: context/skills/processkit/note-management/commands/pk-note-review.md
    classification: removed-upstream
  - path: context/skills/processkit/note-management/commands/pk-note.md
    classification: removed-upstream
  - path: context/skills/processkit/note-management/mcp/SERVER.md
    classification: removed-upstream
  - path: context/skills/processkit/note-management/mcp/mcp-config.json
    classification: removed-upstream
  - path: context/skills/processkit/note-management/mcp/server.py
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-GoalsAnd-context.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-TeamAnd-relationships.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-WorkingStyle.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/assets/goals-and-context.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/assets/identity.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/assets/team-and-relationships.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/assets/working-style.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/commands/pk-observe.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/commands/pk-owner-bootstrap.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/references/interview-protocol.md
    classification: removed-upstream
  - path: context/skills/processkit/owner-profiling/references/observable-signals.md
    classification: removed-upstream
  - path: context/skills/processkit/pk-doctor/scripts/test_pk_doctor_mcp.py
    classification: new-upstream
  - path: context/skills/processkit/process-management/SKILL.md
    classification: removed-upstream
  - path: context/skills/processkit/retrospective/scripts/pk_retro.py
    classification: removed-upstream
  - path: context/skills/processkit/retrospective/scripts/signals/__init__.py
    classification: removed-upstream
  - path: context/skills/processkit/retrospective/scripts/signals/drift.py
    classification: removed-upstream
  - path: context/skills/processkit/retrospective/scripts/signals/release_summary.py
    classification: removed-upstream
  - path: context/skills/processkit/retrospective/scripts/signals/timeline.py
    classification: removed-upstream
  - path: context/skills/processkit/retrospective/scripts/signals/workitems.py
    classification: removed-upstream
  started_at: '2026-07-17T14:32:44+00:00'
  applied_at: '2026-07-17T14:32:45+00:00'
  progress_notes:
  - timestamp: '2026-07-17T14:32:45+00:00'
    actor: mcp
    note: 'Applied after aibox v0.27.2 content reconciliation: no conflicts or stale
      user-owned files; upstream mirror removals were verified by the installer.'
---

# Migration MIG-20260717_1431-ContentSync

From `v0.27.1` to `v0.27.2` (source: `https://github.com/projectious-work/processkit.git`).

0 changed upstream, 0 conflicts, 1 new, 289 removed, 0 stale-removed (28 groups affected)

## Counts

- unchanged: 417
- changed-locally-only: 1
- changed-upstream-only: 0
- conflict: 0
- new-upstream: 1
- removed-upstream: 289
- removed-upstream-stale: 0

## Changes by group

### AGENTS

**changed-locally-only**

- `AGENTS.md` → `AGENTS.md`

### context

**removed-upstream**

- `context/.processkit-mcp-manifest.json` → `context/.processkit-mcp-manifest.json`

### context/artifacts

**removed-upstream**

- `context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-haiku.md` → `context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-haiku.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-mistral-codestral.md` → `context/artifacts/ART-20260503_1424-ModelSpec-mistral-codestral.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v.md` → `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-flash-preview.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-flash-preview.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-3.md` → `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-3.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-1-pro.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-1-pro.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-zai-glm.md` → `context/artifacts/ART-20260503_1424-ModelSpec-zai-glm.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-r.md` → `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-r.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-governed-deep.md` → `context/artifacts/ART-20260503_1832-ModelProfile-governed-deep.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-code-fast.md` → `context/artifacts/ART-20260503_1832-ModelProfile-code-fast.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-writing-balanced.md` → `context/artifacts/ART-20260503_1832-ModelProfile-writing-balanced.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-flash.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-flash.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-o3.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-o3.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-minimax-minimax-m.md` → `context/artifacts/ART-20260503_1424-ModelSpec-minimax-minimax-m.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-general-deep.md` → `context/artifacts/ART-20260503_1832-ModelProfile-general-deep.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-nvidia-nvidia-nemotron-3-super-120b.md` → `context/artifacts/ART-20260503_1424-ModelSpec-nvidia-nvidia-nemotron-3-super-120b.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-code-balanced.md` → `context/artifacts/ART-20260503_1832-ModelProfile-code-balanced.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemma-3-27b.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemma-3-27b.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-research-deep.md` → `context/artifacts/ART-20260503_1832-ModelProfile-research-deep.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-cohere-command-r-plus.md` → `context/artifacts/ART-20260503_1424-ModelSpec-cohere-command-r-plus.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-o4-mini.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-o4-mini.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-2-codex.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-2-codex.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-2-5-pro.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-2-5-pro.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-3-70b.md` → `context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-3-70b.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-2-pro.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-2-pro.md`
- `context/artifacts/ART-20260505_1545-ModelSpec-xiaomi-mimo-7b.md` → `context/artifacts/ART-20260505_1545-ModelSpec-xiaomi-mimo-7b.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-small.md` → `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-small.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok.md` → `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-large.md` → `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-large.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-coder.md` → `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-coder.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-6-plus.md` → `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-6-plus.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-1.md` → `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-1.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-opus.md` → `context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-opus.md`
- `context/artifacts/ART-20260504_1425-ModelSpec-openai-gpt-5-3-codex-spark.md` → `context/artifacts/ART-20260504_1425-ModelSpec-openai-gpt-5-3-codex-spark.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-1-fast.md` → `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-1-fast.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-code-deep.md` → `context/artifacts/ART-20260503_1832-ModelProfile-code-deep.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v4-flash.md` → `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v4-flash.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-4o.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-4o.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-235b.md` → `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-235b.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-deep-think.md` → `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-deep-think.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-5-pro.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-5-pro.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-4-maverick.md` → `context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-4-maverick.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen2-5-coder-32b.md` → `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen2-5-coder-32b.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-sonnet.md` → `context/artifacts/ART-20260503_1424-ModelSpec-anthropic-claude-sonnet.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-general-balanced.md` → `context/artifacts/ART-20260503_1832-ModelProfile-general-balanced.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-minimax-minimax-text.md` → `context/artifacts/ART-20260503_1424-ModelSpec-minimax-minimax-text.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen2-5-72b.md` → `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen2-5-72b.md`
- `context/artifacts/ART-20260503_1832-ModelProfile-general-fast.md` → `context/artifacts/ART-20260503_1832-ModelProfile-general-fast.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-6-max-preview.md` → `context/artifacts/ART-20260503_1424-ModelSpec-alibaba-qwen3-6-max-preview.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-3-5.md` → `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-3-5.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-aws-amazon-nova-2-lite.md` → `context/artifacts/ART-20260503_1424-ModelSpec-aws-amazon-nova-2-lite.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-heavy.md` → `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4-heavy.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-cohere-command-a.md` → `context/artifacts/ART-20260503_1424-ModelSpec-cohere-command-a.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4.md` → `context/artifacts/ART-20260503_1424-ModelSpec-xai-grok-4.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-microsoft-phi.md` → `context/artifacts/ART-20260503_1424-ModelSpec-microsoft-phi.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-mistral-devstral.md` → `context/artifacts/ART-20260503_1424-ModelSpec-mistral-devstral.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v4-pro.md` → `context/artifacts/ART-20260503_1424-ModelSpec-deepseek-deepseek-v4-pro.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-moonshot-kimi-k2-6.md` → `context/artifacts/ART-20260503_1424-ModelSpec-moonshot-kimi-k2-6.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-medium.md` → `context/artifacts/ART-20260503_1424-ModelSpec-mistral-mistral-medium.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-4-scout.md` → `context/artifacts/ART-20260503_1424-ModelSpec-meta-llama-4-scout.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-pro-preview.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-pro-preview.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-2-5-flash.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-2-5-flash.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-pro.md` → `context/artifacts/ART-20260503_1424-ModelSpec-openai-gpt-5-pro.md`
- `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-flash.md` → `context/artifacts/ART-20260503_1424-ModelSpec-google-gemini-3-flash.md`

### context/roles

**removed-upstream**

- `context/roles/ROLE-security-operations-engineer.md` → `context/roles/ROLE-security-operations-engineer.md`
- `context/roles/ROLE-customer-success-manager.md` → `context/roles/ROLE-customer-success-manager.md`
- `context/roles/ROLE-observability-engineer.md` → `context/roles/ROLE-observability-engineer.md`
- `context/roles/ROLE-database-engineer.md` → `context/roles/ROLE-database-engineer.md`
- `context/roles/ROLE-product-owner.md` → `context/roles/ROLE-product-owner.md`
- `context/roles/ROLE-seo-specialist.md` → `context/roles/ROLE-seo-specialist.md`
- `context/roles/ROLE-product-designer.md` → `context/roles/ROLE-product-designer.md`
- `context/roles/ROLE-security-architect.md` → `context/roles/ROLE-security-architect.md`
- `context/roles/ROLE-ai-research-scientist.md` → `context/roles/ROLE-ai-research-scientist.md`
- `context/roles/ROLE-cloud-engineer.md` → `context/roles/ROLE-cloud-engineer.md`
- `context/roles/ROLE-product-manager.md` → `context/roles/ROLE-product-manager.md`
- `context/roles/ROLE-cloud-architect.md` → `context/roles/ROLE-cloud-architect.md`
- `context/roles/ROLE-technical-writer.md` → `context/roles/ROLE-technical-writer.md`
- `context/roles/ROLE-learning-development-manager.md` → `context/roles/ROLE-learning-development-manager.md`
- `context/roles/ROLE-scrum-master.md` → `context/roles/ROLE-scrum-master.md`
- `context/roles/ROLE-ceo.md` → `context/roles/ROLE-ceo.md`
- `context/roles/ROLE-research-scientist.md` → `context/roles/ROLE-research-scientist.md`
- `context/roles/ROLE-machine-learning-engineer.md` → `context/roles/ROLE-machine-learning-engineer.md`
- `context/roles/ROLE-cfo.md` → `context/roles/ROLE-cfo.md`
- `context/roles/ROLE-cpo.md` → `context/roles/ROLE-cpo.md`
- `context/roles/ROLE-general-counsel.md` → `context/roles/ROLE-general-counsel.md`
- `context/roles/ROLE-cto.md` → `context/roles/ROLE-cto.md`
- `context/roles/ROLE-assistant.md` → `context/roles/ROLE-assistant.md`
- `context/roles/ROLE-controller.md` → `context/roles/ROLE-controller.md`
- `context/roles/ROLE-product-marketing-manager.md` → `context/roles/ROLE-product-marketing-manager.md`
- `context/roles/ROLE-cmo.md` → `context/roles/ROLE-cmo.md`
- `context/roles/ROLE-pr-manager.md` → `context/roles/ROLE-pr-manager.md`
- `context/roles/ROLE-coo.md` → `context/roles/ROLE-coo.md`
- `context/roles/ROLE-community-manager.md` → `context/roles/ROLE-community-manager.md`
- `context/roles/ROLE-sales-engineer.md` → `context/roles/ROLE-sales-engineer.md`
- `context/roles/ROLE-program-manager.md` → `context/roles/ROLE-program-manager.md`
- `context/roles/ROLE-recruiter.md` → `context/roles/ROLE-recruiter.md`
- `context/roles/ROLE-account-executive.md` → `context/roles/ROLE-account-executive.md`
- `context/roles/ROLE-financial-analyst.md` → `context/roles/ROLE-financial-analyst.md`
- `context/roles/ROLE-enterprise-architect.md` → `context/roles/ROLE-enterprise-architect.md`
- `context/roles/ROLE-content-marketer.md` → `context/roles/ROLE-content-marketer.md`
- `context/roles/ROLE-embedded-engineer.md` → `context/roles/ROLE-embedded-engineer.md`
- `context/roles/ROLE-devops-engineer.md` → `context/roles/ROLE-devops-engineer.md`
- `context/roles/ROLE-data-scientist.md` → `context/roles/ROLE-data-scientist.md`
- `context/roles/ROLE-treasury-analyst.md` → `context/roles/ROLE-treasury-analyst.md`
- `context/roles/ROLE-solutions-architect.md` → `context/roles/ROLE-solutions-architect.md`
- `context/roles/ROLE-qa-engineer.md` → `context/roles/ROLE-qa-engineer.md`
- `context/roles/ROLE-ux-designer.md` → `context/roles/ROLE-ux-designer.md`
- `context/roles/ROLE-site-reliability-engineer.md` → `context/roles/ROLE-site-reliability-engineer.md`
- `context/roles/ROLE-data-protection-officer.md` → `context/roles/ROLE-data-protection-officer.md`
- `context/roles/ROLE-chief-of-staff.md` → `context/roles/ROLE-chief-of-staff.md`
- `context/roles/ROLE-brand-manager.md` → `context/roles/ROLE-brand-manager.md`
- `context/roles/ROLE-compliance-officer.md` → `context/roles/ROLE-compliance-officer.md`
- `context/roles/ROLE-data-architect.md` → `context/roles/ROLE-data-architect.md`
- `context/roles/ROLE-business-operations-analyst.md` → `context/roles/ROLE-business-operations-analyst.md`
- `context/roles/ROLE-software-engineer.md` → `context/roles/ROLE-software-engineer.md`

### lib

**removed-upstream**

- `context/skills/_lib/README.md` → `context/skills/_lib/README.md`
- `context/skills/_lib/processkit/config.py` → `context/skills/_lib/processkit/config.py`
- `context/skills/_lib/processkit/frontmatter.py` → `context/skills/_lib/processkit/frontmatter.py`
- `context/skills/_lib/processkit/index.py` → `context/skills/_lib/processkit/index.py`
- `context/skills/_lib/processkit/paths.py` → `context/skills/_lib/processkit/paths.py`
- `context/skills/_lib/processkit/log.py` → `context/skills/_lib/processkit/log.py`
- `context/skills/_lib/processkit/__init__.py` → `context/skills/_lib/processkit/__init__.py`
- `context/skills/_lib/processkit/test_frontmatter.py` → `context/skills/_lib/processkit/test_frontmatter.py`
- `context/skills/_lib/processkit/state_machine.py` → `context/skills/_lib/processkit/state_machine.py`
- `context/skills/_lib/processkit/test_ids.py` → `context/skills/_lib/processkit/test_ids.py`
- `context/skills/_lib/processkit/entity.py` → `context/skills/_lib/processkit/entity.py`
- `context/skills/_lib/processkit/ids.py` → `context/skills/_lib/processkit/ids.py`
- `context/skills/_lib/processkit/gateway/catalog.py` → `context/skills/_lib/processkit/gateway/catalog.py`
- `context/skills/_lib/processkit/gateway/naming.py` → `context/skills/_lib/processkit/gateway/naming.py`
- `context/skills/_lib/processkit/gateway/registry.py` → `context/skills/_lib/processkit/gateway/registry.py`
- `context/skills/_lib/processkit/gateway/proxy.py` → `context/skills/_lib/processkit/gateway/proxy.py`
- `context/skills/_lib/processkit/gateway/session.py` → `context/skills/_lib/processkit/gateway/session.py`
- `context/skills/_lib/processkit/gateway/__init__.py` → `context/skills/_lib/processkit/gateway/__init__.py`
- `context/skills/_lib/processkit/gateway/runtime.py` → `context/skills/_lib/processkit/gateway/runtime.py`
- `context/skills/_lib/processkit/gateway/loader.py` → `context/skills/_lib/processkit/gateway/loader.py`
- `context/skills/_lib/processkit/gateway/permissions.py` → `context/skills/_lib/processkit/gateway/permissions.py`
- `context/skills/_lib/processkit/gateway/transports.py` → `context/skills/_lib/processkit/gateway/transports.py`
- `context/skills/_lib/processkit/gateway/lazy.py` → `context/skills/_lib/processkit/gateway/lazy.py`
- `context/skills/_lib/processkit/schema.py` → `context/skills/_lib/processkit/schema.py`

### schemas/INDEX

**removed-upstream**

- `context/schemas/INDEX.md` → `context/schemas/INDEX.md`

### schemas/actor

**removed-upstream**

- `context/schemas/actor.yaml` → `context/schemas/actor.yaml`

### schemas/artifact

**removed-upstream**

- `context/schemas/artifact.yaml` → `context/schemas/artifact.yaml`

### schemas/binding

**removed-upstream**

- `context/schemas/binding.yaml` → `context/schemas/binding.yaml`

### schemas/category

**removed-upstream**

- `context/schemas/category.yaml` → `context/schemas/category.yaml`

### schemas/constraint

**removed-upstream**

- `context/schemas/constraint.yaml` → `context/schemas/constraint.yaml`

### schemas/context

**removed-upstream**

- `context/schemas/context.yaml` → `context/schemas/context.yaml`

### schemas/decisionrecord

**removed-upstream**

- `context/schemas/decisionrecord.yaml` → `context/schemas/decisionrecord.yaml`

### schemas/discussion

**removed-upstream**

- `context/schemas/discussion.yaml` → `context/schemas/discussion.yaml`

### schemas/gate

**removed-upstream**

- `context/schemas/gate.yaml` → `context/schemas/gate.yaml`

### schemas/logentry

**removed-upstream**

- `context/schemas/logentry.yaml` → `context/schemas/logentry.yaml`

### schemas/migration

**removed-upstream**

- `context/schemas/migration.yaml` → `context/schemas/migration.yaml`

### schemas/note

**removed-upstream**

- `context/schemas/note.yaml` → `context/schemas/note.yaml`

### schemas/role

**removed-upstream**

- `context/schemas/role.yaml` → `context/schemas/role.yaml`

### schemas/roleslot

**removed-upstream**

- `context/schemas/roleslot.yaml` → `context/schemas/roleslot.yaml`

### schemas/scope

**removed-upstream**

- `context/schemas/scope.yaml` → `context/schemas/scope.yaml`

### schemas/team-member

**removed-upstream**

- `context/schemas/team-member.yaml` → `context/schemas/team-member.yaml`

### schemas/workitem

**removed-upstream**

- `context/schemas/workitem.yaml` → `context/schemas/workitem.yaml`

### skills/INDEX.md

**removed-upstream**

- `context/skills/INDEX.md` → `context/skills/INDEX.md`

### skills/data-ai

**removed-upstream**

- `context/skills/data-ai/pandas-polars/references/api-comparison.md` → `context/skills/data-ai/pandas-polars/references/api-comparison.md`
- `context/skills/data-ai/pandas-polars/SKILL.md` → `context/skills/data-ai/pandas-polars/SKILL.md`
- `context/skills/data-ai/llm-evaluation/SKILL.md` → `context/skills/data-ai/llm-evaluation/SKILL.md`
- `context/skills/data-ai/data-science/references/tidy-data-principles.md` → `context/skills/data-ai/data-science/references/tidy-data-principles.md`
- `context/skills/data-ai/data-science/references/visualization-guidelines.md` → `context/skills/data-ai/data-science/references/visualization-guidelines.md`
- `context/skills/data-ai/data-science/references/statistical-methods.md` → `context/skills/data-ai/data-science/references/statistical-methods.md`
- `context/skills/data-ai/data-science/SKILL.md` → `context/skills/data-ai/data-science/SKILL.md`
- `context/skills/data-ai/prompt-engineering/references/techniques-catalog.md` → `context/skills/data-ai/prompt-engineering/references/techniques-catalog.md`
- `context/skills/data-ai/prompt-engineering/SKILL.md` → `context/skills/data-ai/prompt-engineering/SKILL.md`
- `context/skills/data-ai/feature-engineering/SKILL.md` → `context/skills/data-ai/feature-engineering/SKILL.md`
- `context/skills/data-ai/data-quality/SKILL.md` → `context/skills/data-ai/data-quality/SKILL.md`
- `context/skills/data-ai/rag-engineering/references/chunking-strategies.md` → `context/skills/data-ai/rag-engineering/references/chunking-strategies.md`
- `context/skills/data-ai/rag-engineering/references/retrieval-patterns.md` → `context/skills/data-ai/rag-engineering/references/retrieval-patterns.md`
- `context/skills/data-ai/rag-engineering/references/evaluation.md` → `context/skills/data-ai/rag-engineering/references/evaluation.md`
- `context/skills/data-ai/rag-engineering/SKILL.md` → `context/skills/data-ai/rag-engineering/SKILL.md`
- `context/skills/data-ai/embedding-vectordb/SKILL.md` → `context/skills/data-ai/embedding-vectordb/SKILL.md`
- `context/skills/data-ai/data-pipeline/SKILL.md` → `context/skills/data-ai/data-pipeline/SKILL.md`
- `context/skills/data-ai/ai-fundamentals/references/math-foundations.md` → `context/skills/data-ai/ai-fundamentals/references/math-foundations.md`
- `context/skills/data-ai/ai-fundamentals/references/ml-concepts.md` → `context/skills/data-ai/ai-fundamentals/references/ml-concepts.md`
- `context/skills/data-ai/ai-fundamentals/SKILL.md` → `context/skills/data-ai/ai-fundamentals/SKILL.md`
- `context/skills/data-ai/ml-pipeline/references/pipeline-stages.md` → `context/skills/data-ai/ml-pipeline/references/pipeline-stages.md`
- `context/skills/data-ai/ml-pipeline/SKILL.md` → `context/skills/data-ai/ml-pipeline/SKILL.md`

### skills/design

**removed-upstream**

- `context/skills/design/mobile-app-design/references/platform-guidelines.md` → `context/skills/design/mobile-app-design/references/platform-guidelines.md`
- `context/skills/design/mobile-app-design/SKILL.md` → `context/skills/design/mobile-app-design/SKILL.md`
- `context/skills/design/seo-optimization/references/technical-seo-checklist.md` → `context/skills/design/seo-optimization/references/technical-seo-checklist.md`
- `context/skills/design/seo-optimization/SKILL.md` → `context/skills/design/seo-optimization/SKILL.md`
- `context/skills/design/logo-design/references/design-principles.md` → `context/skills/design/logo-design/references/design-principles.md`
- `context/skills/design/logo-design/SKILL.md` → `context/skills/design/logo-design/SKILL.md`
- `context/skills/design/excalidraw/references/json-schema.md` → `context/skills/design/excalidraw/references/json-schema.md`
- `context/skills/design/excalidraw/SKILL.md` → `context/skills/design/excalidraw/SKILL.md`
- `context/skills/design/frontend-design/references/accessibility-checklist.md` → `context/skills/design/frontend-design/references/accessibility-checklist.md`
- `context/skills/design/frontend-design/SKILL.md` → `context/skills/design/frontend-design/SKILL.md`

### skills/devops

**removed-upstream**

- `context/skills/devops/linux-administration/references/commands-cheatsheet.md` → `context/skills/devops/linux-administration/references/commands-cheatsheet.md`
- `context/skills/devops/linux-administration/references/systemd-reference.md` → `context/skills/devops/linux-administration/references/systemd-reference.md`
- `context/skills/devops/linux-administration/SKILL.md` → `context/skills/devops/linux-administration/SKILL.md`
- `context/skills/devops/logging-strategy/references/structured-logging.md` → `context/skills/devops/logging-strategy/references/structured-logging.md`
- `context/skills/devops/logging-strategy/SKILL.md` → `context/skills/devops/logging-strategy/SKILL.md`
- `context/skills/devops/incident-response/SKILL.md` → `context/skills/devops/incident-response/SKILL.md`
- `context/skills/devops/metrics-monitoring/references/metric-types.md` → `context/skills/devops/metrics-monitoring/references/metric-types.md`
- `context/skills/devops/metrics-monitoring/SKILL.md` → `context/skills/devops/metrics-monitoring/SKILL.md`
- `context/skills/devops/terraform-basics/SKILL.md` → `context/skills/devops/terraform-basics/SKILL.md`
- `context/skills/devops/container-orchestration/references/compose-patterns.md` → `context/skills/devops/container-orchestration/references/compose-patterns.md`
- `context/skills/devops/container-orchestration/SKILL.md` → `context/skills/devops/container-orchestration/SKILL.md`
- `context/skills/devops/kubernetes-basics/references/cluster-architecture.md` → `context/skills/devops/kubernetes-basics/references/cluster-architecture.md`
- `context/skills/devops/kubernetes-basics/references/troubleshooting.md` → `context/skills/devops/kubernetes-basics/references/troubleshooting.md`
- `context/skills/devops/kubernetes-basics/references/resource-cheatsheet.md` → `context/skills/devops/kubernetes-basics/references/resource-cheatsheet.md`
- `context/skills/devops/kubernetes-basics/SKILL.md` → `context/skills/devops/kubernetes-basics/SKILL.md`
- `context/skills/devops/metrics-management/SKILL.md` → `context/skills/devops/metrics-management/SKILL.md`
- `context/skills/devops/metrics-management/assets/metric-spec.yaml` → `context/skills/devops/metrics-management/assets/metric-spec.yaml`
- `context/skills/devops/dns-networking/references/troubleshooting-tools.md` → `context/skills/devops/dns-networking/references/troubleshooting-tools.md`
- `context/skills/devops/dns-networking/references/protocol-reference.md` → `context/skills/devops/dns-networking/references/protocol-reference.md`
- `context/skills/devops/dns-networking/SKILL.md` → `context/skills/devops/dns-networking/SKILL.md`
- `context/skills/devops/postmortem-writing/SKILL.md` → `context/skills/devops/postmortem-writing/SKILL.md`
- `context/skills/devops/dockerfile-review/SKILL.md` → `context/skills/devops/dockerfile-review/SKILL.md`
- `context/skills/devops/repo-management/mcp/server.py` → `context/skills/devops/repo-management/mcp/server.py`
- `context/skills/devops/repo-management/mcp/SERVER.md` → `context/skills/devops/repo-management/mcp/SERVER.md`
- `context/skills/devops/repo-management/mcp/mcp-config.json` → `context/skills/devops/repo-management/mcp/mcp-config.json`
- `context/skills/devops/repo-management/scripts/test_repo_management.py` → `context/skills/devops/repo-management/scripts/test_repo_management.py`
- `context/skills/devops/repo-management/SKILL.md` → `context/skills/devops/repo-management/SKILL.md`
- `context/skills/devops/repo-management/commands/pk-repo-reconcile.md` → `context/skills/devops/repo-management/commands/pk-repo-reconcile.md`
- `context/skills/devops/distributed-tracing/SKILL.md` → `context/skills/devops/distributed-tracing/SKILL.md`
- `context/skills/devops/ci-cd-setup/SKILL.md` → `context/skills/devops/ci-cd-setup/SKILL.md`
- `context/skills/devops/release-semver/SKILL.md` → `context/skills/devops/release-semver/SKILL.md`
- `context/skills/devops/release-semver/commands/pk-release.md` → `context/skills/devops/release-semver/commands/pk-release.md`
- `context/skills/devops/release-semver/commands/pk-publish.md` → `context/skills/devops/release-semver/commands/pk-publish.md`
- `context/skills/devops/alerting-oncall/SKILL.md` → `context/skills/devops/alerting-oncall/SKILL.md`

### skills/processkit

**new-upstream**

- `context/skills/processkit/pk-doctor/scripts/test_pk_doctor_mcp.py` → `context/skills/processkit/pk-doctor/scripts/test_pk_doctor_mcp.py`

**removed-upstream**

- `context/skills/processkit/eval-gate-authoring/mcp/server.py` → `context/skills/processkit/eval-gate-authoring/mcp/server.py`
- `context/skills/processkit/eval-gate-authoring/mcp/SERVER.md` → `context/skills/processkit/eval-gate-authoring/mcp/SERVER.md`
- `context/skills/processkit/eval-gate-authoring/mcp/mcp-config.json` → `context/skills/processkit/eval-gate-authoring/mcp/mcp-config.json`
- `context/skills/processkit/eval-gate-authoring/scripts/test_eval_gate_authoring.py` → `context/skills/processkit/eval-gate-authoring/scripts/test_eval_gate_authoring.py`
- `context/skills/processkit/eval-gate-authoring/SKILL.md` → `context/skills/processkit/eval-gate-authoring/SKILL.md`
- `context/skills/processkit/owner-profiling/references/observable-signals.md` → `context/skills/processkit/owner-profiling/references/observable-signals.md`
- `context/skills/processkit/owner-profiling/references/interview-protocol.md` → `context/skills/processkit/owner-profiling/references/interview-protocol.md`
- `context/skills/processkit/owner-profiling/SKILL.md` → `context/skills/processkit/owner-profiling/SKILL.md`
- `context/skills/processkit/owner-profiling/commands/pk-owner-bootstrap.md` → `context/skills/processkit/owner-profiling/commands/pk-owner-bootstrap.md`
- `context/skills/processkit/owner-profiling/commands/pk-observe.md` → `context/skills/processkit/owner-profiling/commands/pk-observe.md`
- `context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-TeamAnd-relationships.md` → `context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-TeamAnd-relationships.md`
- `context/skills/processkit/owner-profiling/assets/identity.md` → `context/skills/processkit/owner-profiling/assets/identity.md`
- `context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-GoalsAnd-context.md` → `context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-GoalsAnd-context.md`
- `context/skills/processkit/owner-profiling/assets/goals-and-context.md` → `context/skills/processkit/owner-profiling/assets/goals-and-context.md`
- `context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-WorkingStyle.md` → `context/skills/processkit/owner-profiling/assets/OWNER-20260409_2054-WorkingStyle.md`
- `context/skills/processkit/owner-profiling/assets/working-style.md` → `context/skills/processkit/owner-profiling/assets/working-style.md`
- `context/skills/processkit/owner-profiling/assets/team-and-relationships.md` → `context/skills/processkit/owner-profiling/assets/team-and-relationships.md`
- `context/skills/processkit/note-management/mcp/server.py` → `context/skills/processkit/note-management/mcp/server.py`
- `context/skills/processkit/note-management/mcp/SERVER.md` → `context/skills/processkit/note-management/mcp/SERVER.md`
- `context/skills/processkit/note-management/mcp/mcp-config.json` → `context/skills/processkit/note-management/mcp/mcp-config.json`
- `context/skills/processkit/note-management/SKILL.md` → `context/skills/processkit/note-management/SKILL.md`
- `context/skills/processkit/note-management/commands/pk-note.md` → `context/skills/processkit/note-management/commands/pk-note.md`
- `context/skills/processkit/note-management/commands/pk-note-review.md` → `context/skills/processkit/note-management/commands/pk-note-review.md`
- `context/skills/processkit/note-management/commands/pk-note-promote.md` → `context/skills/processkit/note-management/commands/pk-note-promote.md`
- `context/skills/processkit/aggregate-mcp/mcp/server.py` → `context/skills/processkit/aggregate-mcp/mcp/server.py`
- `context/skills/processkit/aggregate-mcp/mcp/mcp-config.aggregate.json` → `context/skills/processkit/aggregate-mcp/mcp/mcp-config.aggregate.json`
- `context/skills/processkit/aggregate-mcp/scripts/test_aggregate_mcp.py` → `context/skills/processkit/aggregate-mcp/scripts/test_aggregate_mcp.py`
- `context/skills/processkit/aggregate-mcp/SKILL.md` → `context/skills/processkit/aggregate-mcp/SKILL.md`
- `context/skills/processkit/binding-management/mcp/server.py` → `context/skills/processkit/binding-management/mcp/server.py`
- `context/skills/processkit/binding-management/mcp/SERVER.md` → `context/skills/processkit/binding-management/mcp/SERVER.md`
- `context/skills/processkit/binding-management/mcp/mcp-config.json` → `context/skills/processkit/binding-management/mcp/mcp-config.json`
- `context/skills/processkit/binding-management/scripts/test_binding_management.py` → `context/skills/processkit/binding-management/scripts/test_binding_management.py`
- `context/skills/processkit/binding-management/SKILL.md` → `context/skills/processkit/binding-management/SKILL.md`
- `context/skills/processkit/binding-management/assets/binding.yaml` → `context/skills/processkit/binding-management/assets/binding.yaml`
- `context/skills/processkit/index-management/config/settings.toml` → `context/skills/processkit/index-management/config/settings.toml`
- `context/skills/processkit/index-management/mcp/server.py` → `context/skills/processkit/index-management/mcp/server.py`
- `context/skills/processkit/index-management/mcp/SERVER.md` → `context/skills/processkit/index-management/mcp/SERVER.md`
- `context/skills/processkit/index-management/mcp/mcp-config.json` → `context/skills/processkit/index-management/mcp/mcp-config.json`
- `context/skills/processkit/index-management/scripts/test_get_entity_by_path_and_list_entities.py` → `context/skills/processkit/index-management/scripts/test_get_entity_by_path_and_list_entities.py`
- `context/skills/processkit/index-management/scripts/test_db_result_limits.py` → `context/skills/processkit/index-management/scripts/test_db_result_limits.py`
- `context/skills/processkit/index-management/scripts/test_index_management_v1_penalty.py` → `context/skills/processkit/index-management/scripts/test_index_management_v1_penalty.py`
- `context/skills/processkit/index-management/SKILL.md` → `context/skills/processkit/index-management/SKILL.md`
- `context/skills/processkit/agent-management/references/coordination-patterns.md` → `context/skills/processkit/agent-management/references/coordination-patterns.md`
- `context/skills/processkit/agent-management/SKILL.md` → `context/skills/processkit/agent-management/SKILL.md`
- `context/skills/processkit/event-log/mcp/server.py` → `context/skills/processkit/event-log/mcp/server.py`
- `context/skills/processkit/event-log/mcp/SERVER.md` → `context/skills/processkit/event-log/mcp/SERVER.md`
- `context/skills/processkit/event-log/mcp/mcp-config.json` → `context/skills/processkit/event-log/mcp/mcp-config.json`
- `context/skills/processkit/event-log/examples/workitem-transitioned.md` → `context/skills/processkit/event-log/examples/workitem-transitioned.md`
- `context/skills/processkit/event-log/scripts/test_log_event.py` → `context/skills/processkit/event-log/scripts/test_log_event.py`
- `context/skills/processkit/event-log/SKILL.md` → `context/skills/processkit/event-log/SKILL.md`
- `context/skills/processkit/event-log/assets/logentry.yaml` → `context/skills/processkit/event-log/assets/logentry.yaml`
- `context/skills/processkit/artifact-management/mcp/server.py` → `context/skills/processkit/artifact-management/mcp/server.py`
- `context/skills/processkit/artifact-management/mcp/SERVER.md` → `context/skills/processkit/artifact-management/mcp/SERVER.md`
- `context/skills/processkit/artifact-management/mcp/mcp-config.json` → `context/skills/processkit/artifact-management/mcp/mcp-config.json`
- `context/skills/processkit/artifact-management/SKILL.md` → `context/skills/processkit/artifact-management/SKILL.md`
- `context/skills/processkit/process-management/SKILL.md` → `context/skills/processkit/process-management/SKILL.md`
- `context/skills/processkit/retrospective/scripts/signals/timeline.py` → `context/skills/processkit/retrospective/scripts/signals/timeline.py`
- `context/skills/processkit/retrospective/scripts/signals/drift.py` → `context/skills/processkit/retrospective/scripts/signals/drift.py`
- `context/skills/processkit/retrospective/scripts/signals/__init__.py` → `context/skills/processkit/retrospective/scripts/signals/__init__.py`
- `context/skills/processkit/retrospective/scripts/signals/workitems.py` → `context/skills/processkit/retrospective/scripts/signals/workitems.py`
- `context/skills/processkit/retrospective/scripts/signals/release_summary.py` → `context/skills/processkit/retrospective/scripts/signals/release_summary.py`
- `context/skills/processkit/retrospective/scripts/pk_retro.py` → `context/skills/processkit/retrospective/scripts/pk_retro.py`
